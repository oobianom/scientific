library(testthat)
library(scientific)

test_check("tufte")
